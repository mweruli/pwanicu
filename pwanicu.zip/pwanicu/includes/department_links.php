<h2 class="church-widget-heading">[ Departments ]</h2>
<ul style="none">
<li><a href="ict_depertment.php">ICT    Deparment</a></li>
<li><a href="praise&worship.php">Praise & Worship</a></li>
<li><a href="prayer_department.php">Prayer Deparment</a></li>
<li><a href="mission_department.php">Mission Deparment</a></li>
<li><a href="choir _deparment.php">Choir   Deparment</a></li>
<li><a href="creative_ministry.php">Creative Ministry</a></li>
</ul>