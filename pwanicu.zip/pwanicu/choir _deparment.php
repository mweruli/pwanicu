<?php $pageTitle = "Choir Dept"; include('includes/header.php'); ?>

<div class="church-subheader">
	<div class="church-subheader-text">
		<span class="church-subheader-transparent"></span>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h1>Choir Department</h1>
					<div class="clearfix"></div>
					<p class="text-uppercase text-monocase">
						DEPARTMENT OVERVIEW
					</p>
				</div>
			</div>
		</div>
	</div>
	<div class="church-breadcrumb">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<ul>
						<li>
							<a href="index.php">Home</a>
							<i class="fas fa-arrow-right"></i>
						</li>
						<li class="active">ICT Departments</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="church-main-content">

	<div class="church-main-section">
		<div class="container">
			<div class="row">

				<aside class="col-md-3">
					<div class="widget widget_cetagories">
						<?php include('includes/department_links.php'); ?>
					</div>

				</aside>

				<div class="col-md-9">
					<div class="church-blog church-blog-large">
						<ul class="row">
							<li class="col-md-12">
								<div class="church-blog-large-wrap">
									<figure><a href="blog-detail.html"><img src="extra-images/blog-large-img1.jpg" alt=""><i class="fab fa-algolia"></i></a>
										<figcaption class="church-time-date"><small>Choir Deparment</small></figcaption>
									</figure>
									<div class="church-blog-large-text">
										<p class="text-justify">
												This is the oldest group in church history. It comprises a group of musicians that sing and play musical instruments to lead worship in God’s presence. The choir has an eternal function in worshiping Jehovah our God since the Old Testament: 1 Chron. 15, 16; 1Chro:6, 31-35; 2 Chro.7, 6. Revelation: 5, 11. Matt. 26, 30. Acts 16, 25. In RCCG the choir is headed by a coordinator who may have an assistant both reporting to the minister in charge of the choir in the parish, vocalists, back-up singers, and instrumentalists.‍ The Choir Department of <strong>PWANI CU</strong> is a group of born-again Christians who have been set apart to minister to God and His people through music.</p>
												<p class="text-justify"> The choir consists of both instrumentalists and vocalists. The mission statement of the choir is ‘to ensure choir ministration (praise/worship and inspirational songs) are delivered skillfully and in such a manner that it will motivate God’s people to worship Him irrespective of their nationality, race or color’ Additionally, ‘to inspire individuals in the church to imbibe the culture of praise/worship and make it part of their daily routine’.Functions: Providing sacred and gospel music to lead worship during the church services or special events (revival, meetings, weddings, naming or burial, etc.).‍Meeting regularly for rehearsals every week and to learn new songs and hymns‍Providing regular reports of their activities to the pastorate
										</p>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>
<div class="church-main-content">

	<div class="church-main-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="church-team-detail">
						<div class="row">
							<div class="col-md-6">
								<h2 class="church-section-heading"> Choir Department Members </h2>
								<div class="church-team-info">
									<p>Etiam auctor dignissim bibendum. Nunc pulvinar massa nunc, quis pellentesq ue felis suscipit eu.</p>
									<ul>
										<li>
											<h6>John Doe:</h6>
											<span>123456</span>
										</li>
										<li>
											<h6>Jane Doe:</h6>
											<span>123456</span>
										</li>
										<li>
											<h6>John Doe:</h6>
											<span> 123456</span>
										</li>
										<li>
											<h6>John Doe:</h6>
											<span>123456</span>
										</li>
										<li>
											<h6>Jane Doe:</h6>
											<span>123456</span>
										</li>
										<li>
											<h6>John Doe:</h6>
											<span> 123456</span>
										</li>
										<li>
											<h6>Jane Doe:</h6>
											<span>123456</span>
										</li>
									</ul>
								</div>
							</div>
							<div class="col-md-6">
								<h2 class="church-section-heading">Get in Touch With Us</h2>
								<div class="church-team-contact">
									<p>Your email address will not be published. Required fields are marked *</p>
									<form>
										<ul>
											<li>
												<label>Name</label>
												<input value="Type here" onblur="if(this.value == '') { this.value ='Type here'; }" onfocus="if(this.value =='Type here') { this.value = ''; }" tabindex="0" type="text">
											</li>
											<li>
												<label>Email</label>
												<input value="Type here" onblur="if(this.value == '') { this.value ='Type here'; }" onfocus="if(this.value =='Type here') { this.value = ''; }" tabindex="0" type="email">
											</li>
											<li>
												<label>Message</label>
												<textarea placeholder="Type here"></textarea>
											</li>
											<li><input type="submit" value="Send Now"></li>
										</ul>
									</form>
								</div>
							</div>
						</div>
						<!-- <h2 class="church-section-heading">[ Related Members ]</h2> -->
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<?php include('includes/footer.php'); ?>